package com.formacionbdi.springboot.app.gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootServicioGatewayServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
